/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myshipmentproject;
import java.sql.*; 


/**
 *
 * @author User
 */
public class Location {
//class Location
    private String name;
    private String address;

    public Location() {
    }
}