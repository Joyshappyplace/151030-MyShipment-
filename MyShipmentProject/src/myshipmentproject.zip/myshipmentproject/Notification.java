/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myshipmentproject;

import java.util.Date;
import java.sql.*;


/**
 *
 * @author User
 */
public class Notification {
  //class Notification 
    private String message;
    private Date timestamp;
    private String recipient;

    public void sendNotification() {
        // Send notification
        // Implementation details not provided
    }

    public void markAsRead() {
        // Mark notification as read
        // Implementation details not provided
    }
}
