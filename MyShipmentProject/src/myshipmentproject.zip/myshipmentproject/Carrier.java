/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myshipmentproject;
import java.sql.*;
import java.util.List;

/**
 *
 * @author User
 */
public class Carrier {
//class Carrier 
    private String name;
    private String contactInformation;
    private List<String> servicesOffered;

    public String getCarrierInformation() {
        // Get carrier information
        // Implementation details not provided
        return null;
    }

    public String trackShipmentWithCarrier(String trackingNumber) {
        // Track shipment with the carrier
        // Implementation details not provided
        return null;
    }

    public void schedulePickup(Shipment shipment) {
        // Schedule pickup with the carrier
        // Implementation details not provided
    }
}